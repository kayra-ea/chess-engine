package Computational;
import pieces.*;
import java.util.ArrayList;

public class A14 {

    int count = 0;
    int highestScore;
    public A14(){

    }

    public Piece[][] miniMax(ChessDisplay game){ //
        count = 0;
        int lowestScore = Integer.MAX_VALUE;
        Piece[][] bestMove = null;

        //game.log("miniMax of board starting (root=2+)");
        //game.dumpBoard(game.chessboard);

        ArrayList<Piece[][]> moves = game.getAllBoards(1, game.chessboard); //change this so it doesn't need a color
        int score = 0;
        for (Piece[][] move : moves) {
            //Piece[][] clone = move.clone();
            score = min(move, game, 2, game.BLACK, -100000, 100000);
            if (score < lowestScore) {
                lowestScore = score;
                bestMove = move;
            }
        }
        // game.log("minMax: best move (lowest score="+lowestScore+") follows:"); game.dumpBoard(bestMove);
        return bestMove;
    }

    public int min(Piece[][] board, ChessDisplay game, int depth, byte color, int alpha, int beta){
        int val = 0;
        if(depth == 0){
            val = game.EvaluateBoard2(board);
            //game.log("min: leaf (depth==0) EvaluateBoard2: "+val);
            count++;
            return val;
        }

        int highestScore = Integer.MIN_VALUE;

        byte next_color;
        if (color == game.WHITE) {
            next_color = game.BLACK;
        } else {
            next_color = game.WHITE;
        }

        ArrayList<Piece[][]> moves = game.getAllBoards(color, board); //creates the children nodes
        int score = 0;
        for (Piece[][] move : moves) {
            score = max(move, game, depth -1, next_color, alpha, beta);
            if(score <= alpha){
                return alpha;
            }
            if(score < beta){
                beta = score;
            }
        }
        return beta;
    }

    public int max(Piece[][] board, ChessDisplay game, int depth, byte color, int alpha, int beta){
        int val = 0;
        if (depth == 0) {
            val = game.EvaluateBoard2(board);
            //game.log("min: leaf (depth==0) EvaluateBoard2: "+val);
            count++;
            return val;
        }

        int lowestScore = Integer.MAX_VALUE;
        byte next_color;
        if (color == game.WHITE) {
            next_color = game.BLACK;
        } else {
            next_color = game.WHITE;
        }

        ArrayList<Piece[][]> moves = game.getAllBoards(color, board);

        int score = 0;
        for (Piece[][] move : moves) {
            //State clone = state.clone();
            score = min(move, game, depth-1, next_color, alpha, beta);
            if(score >= beta){
                return beta;
            }
            if(score > alpha){
                alpha = score;
            }
        }
        return alpha;
    }

}
