package Computational;

import Main.Chess;
import pieces.*;
import java.util.ArrayList;

public class AI {
    int count = 0;
    public AI(){

    }

    public Piece[][] miniMax2(ChessDisplay game, int depth, boolean isMaximizing){
        if(depth == 0){
            return null;
        }
        int color = 0;
        //get the color to check
        if(isMaximizing){ //then it is white
            color = 0;
        } else if (isMaximizing == false){ //then it is black
            color = 1;
        }

        //instantiate necessary stuff
        //ArrayList<Piece[][]> possibleBoards = game.getAllBoards(color);
        Piece[][] bestMove = null;


        return bestMove;
    }

    /*
    returns the maximum number
     */
    public int max(ChessDisplay game, Piece[][] board){
        return 0;


    }

    /*
    Returns the minimum number
     */
    public int min(){
        return 1;
    }

    public Piece[][] miniMax(ChessDisplay game, int depth, boolean isMaximizingPlayer){
       if(depth ==0){
           //return -game.EvaluateBoard2();
       }

        ArrayList<Piece[][]> possibleBoards = game.getAllBoards(1, game.chessboard);

        Piece[][] bestMove = null;

        int bestValue = -99999;

        return bestMove;
    }

    private int min(ChessDisplay game, Piece[][] board, int depth){
        if(depth ==0){

        }

        return 0;
    }

    private int max(ChessDisplay game, Piece[][] currentBoard, int depth){
        if(depth ==0){

        }

        int lowestValue = Integer.MAX_VALUE;
        for(Piece[][] board: game.getAllBoards(1, currentBoard)){

        }


        return 1;
    }

    public Piece[][] calcBestMove(ChessDisplay game){
        ArrayList<Piece[][]> possibleBoards = game.getAllBoards(1, game.chessboard); //return all possible moves
        System.out.println("size: " + game.getAllBoards(1, game.chessboard).size());

        double x = Math.random()*(game.getAllBoards(1, game.chessboard).size());

        return possibleBoards.get((int)x);
    }
}
