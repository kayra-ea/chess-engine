package Computational;

import pieces.*;
import java.util.ArrayList;

public class AI2 extends Thread{

    int count = 0;

    public AI2(){
    }

    public void run(){
        System.out.println("IS THIS THREAD REALLY WORKING???????");
        return;
    }

    public Piece[][] miniMax(ChessDisplay game){ //
        count = 0;
        int lowestScore = Integer.MAX_VALUE;
        Piece[][] bestMove = null;

        ArrayList<Piece[][]> moves = game.getAllBoards(1, game.chessboard); //change this so it doesn't need a color
        int score = 0;
        for (Piece[][] move : moves) {
            //Piece[][] clone = move.clone();
            score = min(move, game, 2, game.BLACK, -10000, 10000);
            if (score < lowestScore) {
                lowestScore = score;
                bestMove = move;
            }
        }

        if(bestMove == null){
            System.out.println("AHHHHHHHHHHHHH!!!!!!!!!!!!!!!");
            System.out.println("Moves size: " + moves.size());
            return game.chessboard;
        }

        return bestMove;
    }

    public int min(Piece[][] board, ChessDisplay game, int depth, byte color, int alpha, int beta){
        int val = 0;
        if(depth == 0){
            val = game.EvaluateBoard2(board);
            //game.log("min: leaf (depth==0) EvaluateBoard2: "+val);
          //  if(val < beta){ beta = val; }
            count++;
            return val;
        }

        int highestScore = Integer.MAX_VALUE;

        byte next_color;
        if (color == game.WHITE) {
            next_color = game.BLACK;
        } else {
            next_color = game.WHITE;
        }

        ArrayList<Piece[][]> moves = game.getAllBoards(color, board); //creates the children nodes
        int score = 0;
        for (Piece[][] move : moves) {
            score = max(move, game, depth -1, next_color, alpha, beta);

            highestScore = Math.min(highestScore, score);
            beta = Math.min(beta, score);

            if (score < highestScore)
                highestScore = score;

            //game.log("min: max of depth("+depth+")-1: "+score+"; >?highest("+highestScore+")");

            if(alpha >= beta){
                break;
            }

        }

        //game.log("min: depth="+depth+"; returning highest: "+highestScore);
        return highestScore;
    }

    public int max(Piece[][] board, ChessDisplay game, int depth, byte color, int alpha, int beta){
        int val = 0;
        if (depth == 0) {
            val = game.EvaluateBoard2(board);
            //game.log("min: leaf (depth==0) EvaluateBoard2: "+val);
            count++;
            return val;
        }


        int lowestScore = Integer.MIN_VALUE;
        byte next_color;
        if (color == game.WHITE) {
            next_color = game.BLACK;
        } else {
            next_color = game.WHITE;
        }

        ArrayList<Piece[][]> moves = game.getAllBoards(color, board);

        int score = 0;
        for (Piece[][] move : moves) {
            score = min(move, game, depth-1, next_color, alpha, beta);

            lowestScore = Math.max(lowestScore, score);
            alpha =  Math.max(alpha, score);

            //game.log("max: min of depth("+depth+")-1: "+score+"; <?lowest("+lowestScore+")");
            if(alpha >= beta){ //cut-off
                break;
            }
            if (score > lowestScore)
                lowestScore = score;

        }

        //game.log("max: depth="+depth+"; returning lowest: "+lowestScore);
        return lowestScore;
    }

}
